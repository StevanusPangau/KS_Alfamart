def hitungKubus(sisi):
    return sisi ** 3


def hitungBalok(panjang, lebar, tinggi):
    return panjang * lebar * tinggi


def hitungLimasSegiempat(alas, tinggi, tinggi_limas):
    return (alas * tinggi * tinggi_limas) / 3


def hitungPrismaSegitiga(alas, tinggi, tinggi_prisma):
    return (alas * tinggi * tinggi_prisma) / 2
